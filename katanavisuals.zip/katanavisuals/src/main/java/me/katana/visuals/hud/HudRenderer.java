package me.katana.visuals.hud;

import me.katana.visuals.config.KatanaConfig;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.biome.Biome;

/**
 * Лёгкий кастомный HUD. Ничего не читает "сквозь" игру нечестно —
 * все данные (FPS, координаты, нажатые клавиши) и так доступны игроку
 * через F3, мы просто рисуем их красиво и компактно на экране.
 */
public final class HudRenderer implements HudRenderCallback {

    private long sessionStartMillis = -1L;

    private static final int TEXT_COLOR = 0xFFFFFFFF;
    private static final int SHADOW_BG = 0x66000000;

    @Override
    public void onHudRender(DrawContext context, RenderTickCounter tickCounter) {
        KatanaConfig cfg = KatanaConfig.INSTANCE;
        if (!cfg.hudEnabled) return;

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.options.hudHidden) return;

        if (sessionStartMillis < 0) {
            sessionStartMillis = System.currentTimeMillis();
        }

        int x = 6;
        int y = 6;
        int lineHeight = client.textRenderer.fontHeight + 2;

        if (cfg.showFps) {
            drawLine(context, client, "FPS: " + client.getCurrentFps(), x, y);
            y += lineHeight;
        }

        if (cfg.showCoords) {
            var pos = client.player.getPos();
            String coords = String.format("XYZ: %.1f / %.1f / %.1f", pos.x, pos.y, pos.z);
            drawLine(context, client, coords, x, y);
            y += lineHeight;
        }

        if (cfg.showBiome && client.world != null) {
            BlockPos bp = client.player.getBlockPos();
            RegistryEntry<Biome> biome = client.world.getBiome(bp);
            String biomeName = biome.getKey()
                    .map(k -> k.getValue().getPath())
                    .orElse("unknown");
            drawLine(context, client, "Biome: " + biomeName, x, y);
            y += lineHeight;
        }

        if (cfg.showSessionTimer) {
            long elapsed = (System.currentTimeMillis() - sessionStartMillis) / 1000L;
            long h = elapsed / 3600;
            long m = (elapsed % 3600) / 60;
            long s = elapsed % 60;
            String timer = String.format("Session: %02d:%02d:%02d", h, m, s);
            drawLine(context, client, timer, x, y);
            y += lineHeight;
        }

        if (cfg.showKeystrokes) {
            renderKeystrokes(context, client);
        }

        if (cfg.cooldownIndicatorEnabled) {
            renderAttackCooldown(context, client);
        }
    }

    /**
     * Полоска готовности атаки (0..1) прямо над хотбаром — то же самое,
     * что и стандартный "attack indicator: hotbar" из ванильных настроек,
     * только в собственном стиле.
     */
    private void renderAttackCooldown(DrawContext context, MinecraftClient client) {
        if (client.player == null) return;

        float cooldown = client.player.getAttackCooldownProgress(0.0f);
        if (cooldown >= 1.0f) return; // не мешаем, когда атака уже готова

        int screenWidth = client.getWindow().getScaledWidth();
        int screenHeight = client.getWindow().getScaledHeight();

        int barWidth = 60;
        int barHeight = 4;
        int x = screenWidth / 2 - barWidth / 2;
        int y = screenHeight / 2 + 20;

        context.fill(x, y, x + barWidth, y + barHeight, 0x88222222);
        int filled = (int) (barWidth * cooldown);
        int color = 0xFFFFAA00;
        context.fill(x, y, x + filled, y + barHeight, color);
    }

    private void drawLine(DrawContext context, MinecraftClient client, String text, int x, int y) {
        int width = client.textRenderer.getWidth(text);
        context.fill(x - 2, y - 1, x + width + 2, y + client.textRenderer.fontHeight + 1, SHADOW_BG);
        context.drawText(client.textRenderer, text, x, y, TEXT_COLOR, false);
    }

    private void renderKeystrokes(DrawContext context, MinecraftClient client) {
        int screenWidth = client.getWindow().getScaledWidth();
        int baseX = screenWidth - 70;
        int baseY = 10;
        int keySize = 20;
        int gap = 2;

        KeyBinding forward = client.options.forwardKey;
        KeyBinding left = client.options.leftKey;
        KeyBinding back = client.options.backKey;
        KeyBinding right = client.options.rightKey;
        KeyBinding jump = client.options.jumpKey;
        KeyBinding attack = client.options.attackKey;
        KeyBinding use = client.options.useKey;

        drawKey(context, client, "W", baseX + keySize + gap, baseY, keySize, forward.isPressed());
        drawKey(context, client, "A", baseX, baseY + keySize + gap, keySize, left.isPressed());
        drawKey(context, client, "S", baseX + keySize + gap, baseY + keySize + gap, keySize, back.isPressed());
        drawKey(context, client, "D", baseX + 2 * (keySize + gap), baseY + keySize + gap, keySize, right.isPressed());

        int barY = baseY + 2 * (keySize + gap) + gap;
        int barWidth = keySize * 3 + gap * 2;
        drawKeyBar(context, client, "JUMP", baseX, barY, barWidth, 12, jump.isPressed());

        int lmrY = barY + 14;
        drawKeyBar(context, client, "LMB", baseX, lmrY, barWidth / 2 - 1, 12, attack.isPressed());
        drawKeyBar(context, client, "RMB", baseX + barWidth / 2 + 1, lmrY, barWidth / 2 - 1, 12, use.isPressed());
    }

    private void drawKey(DrawContext context, MinecraftClient client, String label, int x, int y, int size, boolean pressed) {
        int bg = pressed ? 0xAA55AA55 : 0x66222222;
        context.fill(x, y, x + size, y + size, bg);
        int textX = x + size / 2 - client.textRenderer.getWidth(label) / 2;
        int textY = y + size / 2 - client.textRenderer.fontHeight / 2;
        context.drawText(client.textRenderer, label, textX, textY, TEXT_COLOR, false);
    }

    private void drawKeyBar(DrawContext context, MinecraftClient client, String label, int x, int y, int w, int h, boolean pressed) {
        int bg = pressed ? 0xAA55AA55 : 0x66222222;
        context.fill(x, y, x + w, y + h, bg);
        int textX = x + w / 2 - client.textRenderer.getWidth(label) / 2;
        int textY = y + h / 2 - client.textRenderer.fontHeight / 2;
        context.drawText(client.textRenderer, label, textX, textY, TEXT_COLOR, false);
    }
}
