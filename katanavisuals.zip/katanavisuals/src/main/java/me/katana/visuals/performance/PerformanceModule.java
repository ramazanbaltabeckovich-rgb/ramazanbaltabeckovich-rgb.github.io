package me.katana.visuals.performance;

import me.katana.visuals.config.KatanaConfig;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.ParticlesMode;

/**
 * Модуль оптимизации FPS. Работает поверх стандартных видео-настроек игры —
 * ничего не патчит "под капотом", просто удобно переключает то, что обычно
 * приходится лазить искать в Options > Video.
 *
 * ВНИМАНИЕ: методы GameOptions (getParticles/getCloudRenderMode/getViewDistance)
 * стабильны в 1.20-1.21.x по Yarn-маппингам, но если между патчами что-то
 * переименовали — тут первое место для правки при ошибке компиляции.
 */
public final class PerformanceModule {

    private static boolean appliedLastTick = false;

    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(PerformanceModule::tick);
    }

    private static void tick(MinecraftClient client) {
        KatanaConfig cfg = KatanaConfig.INSTANCE;
        boolean anyEnabled = cfg.perfReduceParticles || cfg.perfDisableClouds || cfg.perfDisableFog;

        if (!anyEnabled && !appliedLastTick) return;

        applyParticles(client, cfg.perfReduceParticles);
        applyClouds(client, cfg.perfDisableClouds);
        applyRenderDistance(client, cfg.perfDisableFog);

        appliedLastTick = anyEnabled;
    }

    private static void applyParticles(MinecraftClient client, boolean reduce) {
        var option = client.options.getParticles();
        if (reduce && option.getValue() != ParticlesMode.MINIMAL) {
            option.setValue(ParticlesMode.MINIMAL);
        }
    }

    private static void applyClouds(MinecraftClient client, boolean disable) {
        var option = client.options.getCloudRenderMode();
        if (disable && option.getValue() != CloudRenderMode.OFF) {
            option.setValue(CloudRenderMode.OFF);
        }
    }

    private static void applyRenderDistance(MinecraftClient client, boolean reduceFog) {
        // "Меньше тумана" по факту достигается уменьшением дальности прорисовки —
        // честный способ поднять FPS без скрытых от игрока изменений.
        if (!reduceFog) return;
        var option = client.options.getViewDistance();
        if (option.getValue() > 8) {
            option.setValue(8);
        }
    }
}
