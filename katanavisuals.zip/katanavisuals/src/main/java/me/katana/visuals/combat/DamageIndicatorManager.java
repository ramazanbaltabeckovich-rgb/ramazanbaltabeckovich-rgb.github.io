package me.katana.visuals.combat;

import me.katana.visuals.config.KatanaConfig;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Отслеживает изменения здоровья видимых существ (клиентская сторона, те же данные,
 * что игрок и так видит на полоске HP) и показывает всплывающую цифру урона.
 * Никакого доступа к скрытой информации — только визуализация уже известного клиенту стейта.
 */
public final class DamageIndicatorManager {

    private static final Map<UUID, Float> LAST_HEALTH = new HashMap<>();
    private static final List<Popup> ACTIVE = new ArrayList<>();

    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(DamageIndicatorManager::tick);
        WorldRenderEvents.AFTER_ENTITIES.register(DamageIndicatorManager::render);
    }

    private static void tick(MinecraftClient client) {
        if (!KatanaConfig.INSTANCE.damageIndicatorEnabled) return;
        if (client.world == null) return;

        for (Entity entity : client.world.getEntities()) {
            if (!(entity instanceof LivingEntity living)) continue;

            float current = living.getHealth();
            Float previous = LAST_HEALTH.get(living.getUuid());

            if (previous != null && current < previous - 0.01f) {
                float dmg = previous - current;
                spawnPopup(living, dmg);
            }
            LAST_HEALTH.put(living.getUuid(), current);
        }

        ACTIVE.removeIf(Popup::isExpired);
        ACTIVE.forEach(Popup::tick);
    }

    private static void spawnPopup(LivingEntity target, float damage) {
        ACTIVE.add(new Popup(target, damage));
    }

    private static void render(WorldRenderContext ctx) {
        if (ACTIVE.isEmpty()) return;
        MinecraftClient client = MinecraftClient.getInstance();
        Vec3d camPos = ctx.camera().getPos();
        MatrixStack matrices = ctx.matrixStack();
        if (matrices == null) return;

        TextRenderer tr = client.textRenderer;
        VertexConsumerProvider.Immediate vcp = client.getBufferBuilders().getEntityVertexConsumers();

        for (Popup popup : ACTIVE) {
            if (popup.target.isRemoved()) continue;

            double x = popup.target.getX() - camPos.x;
            double y = popup.target.getY() - camPos.y + popup.target.getHeight() + 0.6 + popup.riseOffset();
            double z = popup.target.getZ() - camPos.z;

            matrices.push();
            matrices.translate(x, y, z);
            matrices.multiply(client.gameRenderer.getCamera().getRotation());
            float scale = 0.025f;
            matrices.scale(-scale, -scale, scale);

            String text = String.format("-%.1f", popup.damage);
            int alpha = (int) (popup.alpha() * 255) << 24;
            int color = 0xFFFF5555 & 0x00FFFFFF | alpha;

            int width = tr.getWidth(text);
            tr.draw(text, -width / 2f, 0, color, false, matrices.peek().getPositionMatrix(),
                    vcp, TextRenderer.TextLayerType.NORMAL, 0, 0xF000000);

            matrices.pop();
        }

        vcp.draw();
    }

    private static final class Popup {
        final LivingEntity target;
        final float damage;
        int age = 0;
        static final int LIFETIME = 20; // тиков (~1 сек)

        Popup(LivingEntity target, float damage) {
            this.target = target;
            this.damage = damage;
        }

        void tick() {
            age++;
        }

        boolean isExpired() {
            return age >= LIFETIME;
        }

        double riseOffset() {
            return MathHelper.clampedLerp(0.0, 0.5, age / (float) LIFETIME);
        }

        float alpha() {
            return 1.0f - (age / (float) LIFETIME);
        }
    }
}
