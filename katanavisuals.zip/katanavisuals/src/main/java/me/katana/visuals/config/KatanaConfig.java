package me.katana.visuals.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import me.katana.visuals.markers.Marker;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * Хранилище настроек клиента. Сохраняется в config/katanavisuals.json.
 * Это "текущий активный" конфиг — профили (см. profiles.ProfileManager)
 * это просто именованные снапшоты этого же класса.
 */
public class KatanaConfig {

    public static final Path CONFIG_DIR = FabricLoader.getInstance().getConfigDir().resolve("katanavisuals");
    static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("katanavisuals.json");

    public static KatanaConfig INSTANCE = load();

    // --- Общее / бренд ---
    public String activeProfile = "Default";

    // --- HUD ---
    public boolean hudEnabled = true;
    public boolean showFps = true;
    public boolean showCoords = true;
    public boolean showSessionTimer = true;
    public boolean showKeystrokes = true;
    public boolean showBiome = true;

    // --- Combat ---
    public boolean damageIndicatorEnabled = true;
    public boolean cooldownIndicatorEnabled = true;

    // --- Outlines (только читаемость, не сквозь стены) ---
    public boolean combatOutlinesEnabled = true;
    public float outlineRange = 24.0f;
    public int outlinePlayerColor = 0xFFFF5555;
    public int outlineMobColor = 0xFFFFAA00;

    // --- Крит-звук ---
    public boolean critSoundEnabled = false;
    /** Абсолютный путь к своему .ogg/.wav файлу (пользователь сам подкладывает) либо null = встроенный дефолт */
    public String critSoundCustomPath = null;
    public float critSoundVolume = 1.0f;

    // --- Game Utilities ---
    public boolean durabilityWarningEnabled = true;
    public int durabilityWarningThresholdPercent = 10;
    public boolean potionTimersEnabled = true;

    // --- Markers ---
    public List<Marker> markers = new ArrayList<>();

    // --- Performance ---
    public boolean perfReduceParticles = false;
    public boolean perfDisableClouds = false;
    public boolean perfDisableFog = false;

    public static KatanaConfig load() {
        if (Files.exists(PATH)) {
            try (Reader reader = Files.newBufferedReader(PATH, StandardCharsets.UTF_8)) {
                KatanaConfig cfg = GSON.fromJson(reader, KatanaConfig.class);
                if (cfg != null) {
                    if (cfg.markers == null) cfg.markers = new ArrayList<>();
                    return cfg;
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        KatanaConfig cfg = new KatanaConfig();
        cfg.save();
        return cfg;
    }

    public void save() {
        try {
            Files.createDirectories(PATH.getParent());
            try (Writer writer = Files.newBufferedWriter(PATH, StandardCharsets.UTF_8)) {
                GSON.toJson(this, writer);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
