package me.katana.visuals.sound;

import me.katana.visuals.config.KatanaConfig;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;

import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import java.io.File;

/**
 * Определяет крит по тем же условиям, что и ванильная игра
 * (падение + не на земле + не в воде/лестнице + без Blindness + не спринт +
 * полностью заряженная атака) — это всё данные, которые клиент и так знает
 * о своём собственном игроке, ничего "скрытого" мы не читаем.
 *
 * Звук: если пользователь указал свой .wav файл в конфиге — играем его
 * напрямую через javax.sound (без завязки на ресурс-паки Minecraft).
 * Иначе — встроенный дефолтный звук игры.
 */
public final class CritSoundManager {

    public static void register() {
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (!world.isClient) return ActionResult.PASS;
            if (player != MinecraftClient.getInstance().player) return ActionResult.PASS;

            if (isLikelyCrit(player)) {
                playCritSound();
            }
            return ActionResult.PASS;
        });
    }

    private static boolean isLikelyCrit(net.minecraft.entity.player.PlayerEntity player) {
        float cooldown = player.getAttackCooldownProgress(0.0f);

        return cooldown >= 0.9f
                && player.fallDistance > 0.0f
                && !player.isOnGround()
                && !player.isClimbing()
                && !player.isTouchingWater()
                && !player.hasVehicle()
                && !player.isSprinting()
                && !player.hasStatusEffect(StatusEffects.BLINDNESS);
    }

    /** Проигрывает текущий настроенный крит-звук вне зависимости от того, включён ли он — для кнопки "Тест" в GUI. */
    public static void testPlay() {
        KatanaConfig cfg = KatanaConfig.INSTANCE;
        if (cfg.critSoundCustomPath != null && !cfg.critSoundCustomPath.isBlank()) {
            playCustomFile(cfg.critSoundCustomPath, cfg.critSoundVolume);
        } else {
            MinecraftClient client = MinecraftClient.getInstance();
            client.getSoundManager().play(PositionedSoundInstance.master(
                    SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 1.4f, cfg.critSoundVolume));
        }
    }

    private static void playCritSound() {
        KatanaConfig cfg = KatanaConfig.INSTANCE;
        if (!cfg.critSoundEnabled) return;

        if (cfg.critSoundCustomPath != null && !cfg.critSoundCustomPath.isBlank()) {
            playCustomFile(cfg.critSoundCustomPath, cfg.critSoundVolume);
        } else {
            MinecraftClient client = MinecraftClient.getInstance();
            client.getSoundManager().play(PositionedSoundInstance.master(
                    SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 1.4f, cfg.critSoundVolume));
        }
    }

    /**
     * Проигрывает произвольный .wav файл с диска через стандартный javax.sound.
     * OGG/MP3 так не сыграть без доп. библиотек — предупреди пользователя,
     * что файл должен быть именно .wav.
     */
    private static void playCustomFile(String path, float volume) {
        try {
            File file = new File(path);
            if (!file.exists()) return;

            Clip clip = AudioSystem.getClip();
            clip.open(AudioSystem.getAudioInputStream(file));

            if (clip.isControlSupported(javax.sound.sampled.FloatControl.Type.MASTER_GAIN)) {
                var gainControl = (javax.sound.sampled.FloatControl)
                        clip.getControl(javax.sound.sampled.FloatControl.Type.MASTER_GAIN);
                float clamped = Math.max(0.0001f, Math.min(1f, volume));
                gainControl.setValue(20f * (float) Math.log10(clamped));
            }

            clip.start();
            clip.addLineListener(event -> {
                if (event.getType() == javax.sound.sampled.LineEvent.Type.STOP) {
                    clip.close();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
