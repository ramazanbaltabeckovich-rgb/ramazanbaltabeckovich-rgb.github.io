package me.katana.visuals.gui;

import me.katana.visuals.config.KatanaConfig;
import me.katana.visuals.markers.Marker;
import me.katana.visuals.markers.MarkerManager;
import me.katana.visuals.profiles.ProfileManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/**
 * Главный экран клиента — фирменная красная тема KatanaVisuals.
 * Открывается по хоткею (по умолчанию Right Control) поверх игры.
 */
public class KatanaVisualsScreen extends Screen {

    // --- Фирменные цвета (красная тема) ---
    private static final int COL_BG_TOP = 0xEE1A0000;
    private static final int COL_BG_BOTTOM = 0xEE330000;
    private static final int COL_PANEL = 0xCC220000;
    private static final int COL_ACCENT = 0xFFE00000;
    private static final int COL_ACCENT_BRIGHT = 0xFFFF3333;
    private static final int COL_TEXT = 0xFFF5DADA;

    private enum Tab { HUD, COMBAT, UTILITIES, MARKERS, CONFIGS, PERFORMANCE }

    private Tab currentTab = Tab.HUD;
    private final KatanaConfig cfg = KatanaConfig.INSTANCE;

    private TextFieldWidget markerNameField;
    private TextFieldWidget profileNameField;
    private TextFieldWidget critSoundPathField;

    private record Label(int x, int y, String text) {}
    private final java.util.List<Label> labels = new java.util.ArrayList<>();

    public KatanaVisualsScreen() {
        super(Text.literal("KatanaVisuals"));
    }

    @Override
    protected void init() {
        super.init();
        int tabY = 34;
        int tabW = 90;
        int x = this.width / 2 - (tabW * Tab.values().length) / 2;

        for (Tab tab : Tab.values()) {
            int finalX = x;
            this.addDrawableChild(new RedButton(x, tabY, tabW - 2, 20, Text.literal(tabName(tab)),
                    b -> { currentTab = tab; rebuild(); }));
            x += tabW;
        }

        rebuild();
    }

    private String tabName(Tab tab) {
        return switch (tab) {
            case HUD -> "HUD";
            case COMBAT -> "Combat";
            case UTILITIES -> "Utilities";
            case MARKERS -> "Markers";
            case CONFIGS -> "Configs";
            case PERFORMANCE -> "Performance";
        };
    }

    /** Пересобирает виджеты под текущий таб (кроме верхних кнопок табов). */
    private void rebuild() {
        this.clearChildren();
        this.labels.clear();
        int tabY = 34;
        int tabW = 90;
        int x = this.width / 2 - (tabW * Tab.values().length) / 2;
        for (Tab tab : Tab.values()) {
            int finalX = x;
            this.addDrawableChild(new RedButton(x, tabY, tabW - 2, 20, Text.literal(tabName(tab)),
                    b -> { currentTab = tab; rebuild(); }));
            x += tabW;
        }

        int contentX = this.width / 2 - 140;
        int y = 66;

        switch (currentTab) {
            case HUD -> {
                y = addToggle(contentX, y, "FPS", () -> cfg.showFps, v -> cfg.showFps = v);
                y = addToggle(contentX, y, "Координаты", () -> cfg.showCoords, v -> cfg.showCoords = v);
                y = addToggle(contentX, y, "Биом", () -> cfg.showBiome, v -> cfg.showBiome = v);
                y = addToggle(contentX, y, "Таймер сессии", () -> cfg.showSessionTimer, v -> cfg.showSessionTimer = v);
                y = addToggle(contentX, y, "Keystrokes", () -> cfg.showKeystrokes, v -> cfg.showKeystrokes = v);
                addToggle(contentX, y, "HUD включён", () -> cfg.hudEnabled, v -> cfg.hudEnabled = v);
            }
            case COMBAT -> {
                y = addToggle(contentX, y, "Индикатор урона", () -> cfg.damageIndicatorEnabled, v -> cfg.damageIndicatorEnabled = v);
                y = addToggle(contentX, y, "Индикатор КД атаки", () -> cfg.cooldownIndicatorEnabled, v -> cfg.cooldownIndicatorEnabled = v);
                y = addToggle(contentX, y, "Маркеры целей в бою", () -> cfg.combatOutlinesEnabled, v -> cfg.combatOutlinesEnabled = v);
                y += 6;
                y = addToggle(contentX, y, "Звук на крит", () -> cfg.critSoundEnabled, v -> cfg.critSoundEnabled = v);

                critSoundPathField = new TextFieldWidget(this.textRenderer, contentX, y, 200, 18, Text.literal("Путь к .wav"));
                critSoundPathField.setMaxLength(260);
                critSoundPathField.setText(cfg.critSoundCustomPath == null ? "" : cfg.critSoundCustomPath);
                critSoundPathField.setChangedListener(s -> {
                    cfg.critSoundCustomPath = s.isBlank() ? null : s;
                    cfg.save();
                });
                this.addDrawableChild(critSoundPathField);
                this.addDrawableChild(new RedButton(contentX + 205, y - 1, 65, 20, Text.literal("Тест"),
                        b -> me.katana.visuals.sound.CritSoundManager.testPlay()));
                y += 26;
                labels.add(new Label(contentX, y, "Свой .wav файл лежит на диске — впиши полный путь. Пусто = встроенный звук."));
            }
            case UTILITIES -> {
                y = addToggle(contentX, y, "Предупреждение о прочности", () -> cfg.durabilityWarningEnabled, v -> cfg.durabilityWarningEnabled = v);
                y = addToggle(contentX, y, "Таймеры эффектов зелий", () -> cfg.potionTimersEnabled, v -> cfg.potionTimersEnabled = v);
            }
            case MARKERS -> {
                markerNameField = new TextFieldWidget(this.textRenderer, contentX, y, 180, 18, Text.literal("Имя метки"));
                markerNameField.setMaxLength(32);
                markerNameField.setText("Marker");
                this.addDrawableChild(markerNameField);
                this.addDrawableChild(new RedButton(contentX + 185, y - 1, 90, 20, Text.literal("+ Добавить"), b -> {
                    String name = markerNameField.getText().isBlank() ? "Marker" : markerNameField.getText();
                    MarkerManager.addMarkerAtPlayer(name, COL_ACCENT_BRIGHT);
                    rebuild();
                }));
                y += 26;

                for (Marker marker : cfg.markers) {
                    labels.add(new Label(contentX, y + 4, marker.name +
                            String.format("  (%.0f, %.0f, %.0f)", marker.x, marker.y, marker.z)));
                    this.addDrawableChild(new RedButton(contentX + 240, y, 55, 18, Text.literal("Удалить"), b -> {
                        MarkerManager.remove(marker);
                        rebuild();
                    }));
                    y += 22;
                }
            }
            case CONFIGS -> {
                profileNameField = new TextFieldWidget(this.textRenderer, contentX, y, 180, 18, Text.literal("Имя профиля"));
                profileNameField.setMaxLength(32);
                profileNameField.setText(cfg.activeProfile);
                this.addDrawableChild(profileNameField);
                this.addDrawableChild(new RedButton(contentX + 185, y - 1, 90, 20, Text.literal("Сохранить"), b -> {
                    String name = profileNameField.getText().isBlank() ? "Profile" : profileNameField.getText();
                    ProfileManager.saveProfile(name);
                    cfg.activeProfile = name;
                    cfg.save();
                    rebuild();
                }));
                y += 26;

                for (String profile : ProfileManager.listProfiles()) {
                    boolean active = profile.equals(cfg.activeProfile);
                    labels.add(new Label(contentX, y + 4, (active ? "▶ " : "   ") + profile));
                    this.addDrawableChild(new RedButton(contentX + 180, y, 55, 18, Text.literal("Загрузить"), b -> {
                        ProfileManager.loadProfile(profile);
                        rebuild();
                    }));
                    this.addDrawableChild(new RedButton(contentX + 240, y, 55, 18, Text.literal("Удалить"), b -> {
                        ProfileManager.deleteProfile(profile);
                        rebuild();
                    }));
                    y += 22;
                }
            }
            case PERFORMANCE -> {
                y = addToggle(contentX, y, "Меньше частиц", () -> cfg.perfReduceParticles, v -> cfg.perfReduceParticles = v);
                y = addToggle(contentX, y, "Отключить облака", () -> cfg.perfDisableClouds, v -> cfg.perfDisableClouds = v);
                addToggle(contentX, y, "Меньше тумана (снижает Render Distance)", () -> cfg.perfDisableFog, v -> cfg.perfDisableFog = v);
            }
        }
    }

    private int addToggle(int x, int y, String label, BooleanSupplier getter, Consumer<Boolean> setter) {
        boolean current = getter.getAsBoolean();
        this.addDrawableChild(new RedButton(x, y, 300, 20,
                Text.literal(label + ": " + (current ? "ВКЛ" : "ВЫКЛ")), b -> {
            boolean newVal = !getter.getAsBoolean();
            setter.accept(newVal);
            cfg.save();
            rebuild();
        }));
        return y + 24;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fillGradient(0, 0, this.width, this.height, COL_BG_TOP, COL_BG_BOTTOM);
        context.fill(this.width / 2 - 150, 8, this.width / 2 + 150, 30, COL_PANEL);
        context.drawCenteredTextWithShadow(this.textRenderer, "⚔ KatanaVisuals ⚔", this.width / 2, 14, COL_ACCENT_BRIGHT);

        for (Label label : labels) {
            context.drawTextWithShadow(this.textRenderer, label.text(), label.x(), label.y(), COL_TEXT);
        }

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    // --- Простые внутренние виджеты в красной теме ---

    private class RedButton extends ButtonWidget {
        protected RedButton(int x, int y, int width, int height, Text message, PressAction onPress) {
            super(x, y, width, height, message, onPress, DEFAULT_NARRATION_SUPPLIER);
        }

        @Override
        public void renderWidget(DrawContext context, int mouseX, int mouseY, float delta) {
            boolean hovered = isMouseOver(mouseX, mouseY);
            int bg = hovered ? COL_ACCENT_BRIGHT : COL_ACCENT;
            context.fill(getX(), getY(), getX() + getWidth(), getY() + getHeight(), bg);
            context.drawCenteredTextWithShadow(textRenderer, getMessage(),
                    getX() + getWidth() / 2, getY() + (getHeight() - 8) / 2, 0xFFFFFFFF);
        }
    }
}
