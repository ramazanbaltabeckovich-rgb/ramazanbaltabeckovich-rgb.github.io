package me.katana.visuals.utilities;

import me.katana.visuals.config.KatanaConfig;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;

import java.util.Collection;

/**
 * Полезные, честные QoL-фичи: предупреждение "у тебя меч вот-вот сломается"
 * и компактный список активных эффектов с таймерами.
 */
public final class GameUtilitiesHud implements HudRenderCallback {

    @Override
    public void onHudRender(DrawContext context, RenderTickCounter tickCounter) {
        KatanaConfig cfg = KatanaConfig.INSTANCE;
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.options.hudHidden) return;

        if (cfg.durabilityWarningEnabled) {
            renderDurabilityWarning(context, client, cfg);
        }
        if (cfg.potionTimersEnabled) {
            renderPotionTimers(context, client);
        }
    }

    private void renderDurabilityWarning(DrawContext context, MinecraftClient client, KatanaConfig cfg) {
        ItemStack mainHand = client.player.getMainHandStack();
        if (mainHand.isEmpty() || !mainHand.isDamageable()) return;

        int max = mainHand.getMaxDamage();
        int current = max - mainHand.getDamage();
        int percent = (int) (100.0 * current / max);
        if (percent > cfg.durabilityWarningThresholdPercent) return;

        String text = "⚠ " + mainHand.getName().getString() + ": " + percent + "%";
        int screenWidth = client.getWindow().getScaledWidth();
        int width = client.textRenderer.getWidth(text);
        int x = screenWidth / 2 - width / 2;
        int y = client.getWindow().getScaledHeight() - 60;

        context.fill(x - 3, y - 2, x + width + 3, y + client.textRenderer.fontHeight + 2, 0x99330000);
        context.drawText(client.textRenderer, text, x, y, 0xFFFF5555, true);
    }

    private void renderPotionTimers(DrawContext context, MinecraftClient client) {
        Collection<StatusEffectInstance> effects = client.player.getStatusEffects();
        if (effects.isEmpty()) return;

        int screenWidth = client.getWindow().getScaledWidth();
        int x = screenWidth - 6;
        int y = 90;
        int lineHeight = client.textRenderer.fontHeight + 2;

        for (StatusEffectInstance effect : effects) {
            String name = effect.getEffectType().value().getName().getString();
            int duration = effect.getDuration();
            String time = formatTime(duration);
            String line = name + " " + (effect.getAmplifier() + 1) + " (" + time + ")";
            int width = client.textRenderer.getWidth(line);
            int drawX = x - width;

            context.fill(drawX - 2, y - 1, x + 2, y + client.textRenderer.fontHeight + 1, 0x66000000);
            context.drawText(client.textRenderer, line, drawX, y, 0xFFFFFFFF, false);
            y += lineHeight;
        }
    }

    private String formatTime(int ticks) {
        int totalSeconds = ticks / 20;
        int m = totalSeconds / 60;
        int s = totalSeconds % 60;
        return String.format("%d:%02d", m, s);
    }
}
