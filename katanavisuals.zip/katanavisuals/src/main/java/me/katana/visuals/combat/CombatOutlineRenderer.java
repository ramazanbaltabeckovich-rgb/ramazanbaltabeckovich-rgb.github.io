package me.katana.visuals.combat;

import com.mojang.blaze3d.systems.RenderSystem;
import me.katana.visuals.config.KatanaConfig;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

/**
 * ВАЖНО: маркеры рисуются внутри обычного 3D-прохода мира (WorldRenderEvents.AFTER_ENTITIES),
 * где активен depth test — то есть блоки перед целью корректно перекрывают маркер.
 * Это НЕ esp/wallhack: цель не видна сквозь стены, только чуть заметнее в честном бою.
 */
public final class CombatOutlineRenderer {

    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(CombatOutlineRenderer::render);
    }

    private static void render(WorldRenderContext ctx) {
        KatanaConfig cfg = KatanaConfig.INSTANCE;
        if (!cfg.combatOutlinesEnabled) return;

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) return;

        Vec3d camPos = ctx.camera().getPos();
        MatrixStack matrices = ctx.matrixStack();
        if (matrices == null) return;

        VertexConsumerProvider.Immediate vcp = client.getBufferBuilders().getEntityVertexConsumers();

        for (Entity entity : client.world.getEntities()) {
            if (entity == client.player) continue;
            if (!(entity instanceof LivingEntity living)) continue;
            if (living.isRemoved() || !living.isAlive()) continue;

            // Только игроки и враждебные мобы — не превращаем это в маркер каждой курицы
            boolean relevant = entity instanceof PlayerEntity || entity instanceof HostileEntity;
            if (!relevant) continue;

            double dist = entity.getPos().distanceTo(client.player.getPos());
            if (dist > cfg.outlineRange) continue;

            int color = entity instanceof PlayerEntity ? cfg.outlinePlayerColor : cfg.outlineMobColor;
            drawMarker(matrices, vcp, entity, camPos, color, ctx.tickCounter().getTickProgress(true));
        }

        vcp.draw();
    }

    private static void drawMarker(MatrixStack matrices, VertexConsumerProvider.Immediate vcp,
                                    Entity entity, Vec3d camPos, int argb, float tickDelta) {
        double x = MathHelper.lerp(tickDelta, entity.lastRenderX, entity.getX()) - camPos.x;
        double y = MathHelper.lerp(tickDelta, entity.lastRenderY, entity.getY()) - camPos.y
                + entity.getHeight() + 0.35;
        double z = MathHelper.lerp(tickDelta, entity.lastRenderZ, entity.getZ()) - camPos.z;

        matrices.push();
        matrices.translate(x, y, z);
        // Разворачиваем маркер к камере (billboard)
        matrices.multiply(MinecraftClient.getInstance().gameRenderer.getCamera().getRotation());
        matrices.scale(0.5f, 0.5f, 0.5f);

        float a = ((argb >> 24) & 0xFF) / 255f;
        float r = ((argb >> 16) & 0xFF) / 255f;
        float g = ((argb >> 8) & 0xFF) / 255f;
        float b = (argb & 0xFF) / 255f;

        Matrix4f model = matrices.peek().getPositionMatrix();
        VertexConsumer buffer = vcp.getBuffer(RenderLayer.getDebugFilledBox());

        float s = 0.12f;
        // Маленький ромб-маркер (billboard quad)
        buffer.vertex(model, 0f, s, 0f).color(r, g, b, a);
        buffer.vertex(model, -s, 0f, 0f).color(r, g, b, a);
        buffer.vertex(model, 0f, -s, 0f).color(r, g, b, a);
        buffer.vertex(model, s, 0f, 0f).color(r, g, b, a);

        matrices.pop();
    }
}
