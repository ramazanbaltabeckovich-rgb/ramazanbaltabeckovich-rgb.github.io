package me.katana.visuals.markers;

public class Marker {
    public String name;
    public double x, y, z;
    public String dimension; // например "minecraft:overworld"
    public int color = 0xFFFF3333; // ARGB, по умолчанию красный (в стиле бренда)

    public Marker() {
    }

    public Marker(String name, double x, double y, double z, String dimension, int color) {
        this.name = name;
        this.x = x;
        this.y = y;
        this.z = z;
        this.dimension = dimension;
        this.color = color;
    }
}
