package me.katana.visuals;

import me.katana.visuals.combat.CombatOutlineRenderer;
import me.katana.visuals.combat.DamageIndicatorManager;
import me.katana.visuals.config.KatanaConfig;
import me.katana.visuals.gui.KatanaVisualsScreen;
import me.katana.visuals.hud.HudRenderer;
import me.katana.visuals.markers.MarkerManager;
import me.katana.visuals.performance.PerformanceModule;
import me.katana.visuals.profiles.ProfileManager;
import me.katana.visuals.sound.CritSoundManager;
import me.katana.visuals.utilities.GameUtilitiesHud;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class KatanaVisualsClient implements ClientModInitializer {

    public static final String MOD_ID = "katanavisuals";

    private static KeyBinding toggleHudKey;
    private static KeyBinding openMenuKey;

    @Override
    public void onInitializeClient() {
        // Загружаем/создаём конфиг и профили
        KatanaConfig.INSTANCE = KatanaConfig.load();
        ProfileManager.init();

        // HUD и утилиты
        HudRenderCallback.EVENT.register(new HudRenderer());
        HudRenderCallback.EVENT.register(new GameUtilitiesHud());

        // Боевые фичи
        DamageIndicatorManager.register();
        CombatOutlineRenderer.register();
        CritSoundManager.register();

        // Метки и производительность
        MarkerManager.register();
        PerformanceModule.register();

        // Хоткей вкл/выкл HUD
        toggleHudKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.katanavisuals.toggle_hud",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.katanavisuals.general"
        ));

        // Хоткей открытия красного UI клиента
        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.katanavisuals.open_menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_CONTROL,
                "category.katanavisuals.general"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleHudKey.wasPressed()) {
                KatanaConfig.INSTANCE.hudEnabled = !KatanaConfig.INSTANCE.hudEnabled;
                KatanaConfig.INSTANCE.save();
            }
            while (openMenuKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new KatanaVisualsScreen());
                }
            }
        });
    }
}
