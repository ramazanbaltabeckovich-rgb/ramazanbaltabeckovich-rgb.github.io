package me.katana.visuals.profiles;

import me.katana.visuals.config.KatanaConfig;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

/**
 * Профили хранятся как отдельные json-файлы в config/katanavisuals/profiles/*.json,
 * каждый — полный снапшот KatanaConfig. Позволяет сохранить набор настроек
 * (например "PvP", "Просто играть", "Стрим") и переключаться в один клик.
 */
public final class ProfileManager {

    private static final Path PROFILES_DIR = KatanaConfig.CONFIG_DIR.resolve("profiles");

    private ProfileManager() {
    }

    public static void init() {
        try {
            Files.createDirectories(PROFILES_DIR);
            // Гарантируем, что есть профиль "Default" на первом запуске
            Path def = PROFILES_DIR.resolve("Default.json");
            if (!Files.exists(def)) {
                saveProfile("Default");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static List<String> listProfiles() {
        List<String> names = new ArrayList<>();
        if (!Files.isDirectory(PROFILES_DIR)) return names;
        try (Stream<Path> files = Files.list(PROFILES_DIR)) {
            files.filter(p -> p.toString().endsWith(".json"))
                    .forEach(p -> {
                        String fileName = p.getFileName().toString();
                        names.add(fileName.substring(0, fileName.length() - ".json".length()));
                    });
        } catch (IOException e) {
            e.printStackTrace();
        }
        names.sort(String::compareToIgnoreCase);
        return names;
    }

    /** Сохраняет ТЕКУЩИЙ активный конфиг под указанным именем профиля. */
    public static void saveProfile(String name) {
        Path path = PROFILES_DIR.resolve(sanitize(name) + ".json");
        try {
            Files.createDirectories(PROFILES_DIR);
            try (Writer writer = Files.newBufferedWriter(path, StandardCharsets.UTF_8)) {
                KatanaConfig.GSON.toJson(KatanaConfig.INSTANCE, writer);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /** Загружает профиль по имени и делает его активным конфигом клиента. */
    public static boolean loadProfile(String name) {
        Path path = PROFILES_DIR.resolve(sanitize(name) + ".json");
        if (!Files.exists(path)) return false;

        try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            KatanaConfig loaded = KatanaConfig.GSON.fromJson(reader, KatanaConfig.class);
            if (loaded == null) return false;
            loaded.activeProfile = name;
            KatanaConfig.INSTANCE = loaded;
            KatanaConfig.INSTANCE.save();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static void deleteProfile(String name) {
        Path path = PROFILES_DIR.resolve(sanitize(name) + ".json");
        try {
            Files.deleteIfExists(path);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static String sanitize(String name) {
        return name.replaceAll("[^a-zA-Z0-9_\\-А-Яа-яЁё ]", "_");
    }
}
