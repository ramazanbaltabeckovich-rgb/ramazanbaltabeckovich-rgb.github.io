package me.katana.visuals.markers;

import me.katana.visuals.config.KatanaConfig;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.util.List;

/**
 * Система меток (waypoints) — это просто заметки самого игрока о собственных
 * координатах ("тут база", "тут шахта"), никак не связано с обнаружением
 * других сущностей.
 */
public final class MarkerManager {

    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(MarkerManager::render);
    }

    public static Marker addMarkerAtPlayer(String name, int color) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) return null;

        var pos = client.player.getPos();
        String dim = client.world.getRegistryKey().getValue().toString();
        Marker marker = new Marker(name, pos.x, pos.y, pos.z, dim, color);
        KatanaConfig.INSTANCE.markers.add(marker);
        KatanaConfig.INSTANCE.save();
        return marker;
    }

    public static void remove(Marker marker) {
        KatanaConfig.INSTANCE.markers.remove(marker);
        KatanaConfig.INSTANCE.save();
    }

    private static void render(WorldRenderContext ctx) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null || client.player == null) return;

        List<Marker> markers = KatanaConfig.INSTANCE.markers;
        if (markers.isEmpty()) return;

        String currentDim = client.world.getRegistryKey().getValue().toString();
        Vec3d camPos = ctx.camera().getPos();
        MatrixStack matrices = ctx.matrixStack();
        if (matrices == null) return;

        VertexConsumerProvider.Immediate vcp = client.getBufferBuilders().getEntityVertexConsumers();
        TextRenderer tr = client.textRenderer;

        for (Marker marker : markers) {
            if (!currentDim.equals(marker.dimension)) continue;

            double dx = marker.x - camPos.x;
            double dy = marker.y - camPos.y;
            double dz = marker.z - camPos.z;
            double dist = client.player.getPos().distanceTo(new Vec3d(marker.x, marker.y, marker.z));

            drawBeam(matrices, vcp, dx, dy, dz, marker.color);

            matrices.push();
            matrices.translate(dx, dy + 1.6, dz);
            matrices.multiply(client.gameRenderer.getCamera().getRotation());
            float scale = 0.03f;
            matrices.scale(-scale, -scale, scale);

            String label = marker.name + " (" + (int) dist + "m)";
            int width = tr.getWidth(label);
            Matrix4f model = matrices.peek().getPositionMatrix();
            tr.draw(label, -width / 2f, 0, marker.color, false, model,
                    vcp, TextRenderer.TextLayerType.NORMAL, 0, 0xF000000);

            matrices.pop();
        }

        vcp.draw();
    }

    private static void drawBeam(MatrixStack matrices, VertexConsumerProvider.Immediate vcp,
                                  double dx, double dy, double dz, int argb) {
        matrices.push();
        matrices.translate(dx, dy, dz);

        float a = 0.55f;
        float r = ((argb >> 16) & 0xFF) / 255f;
        float g = ((argb >> 8) & 0xFF) / 255f;
        float b = (argb & 0xFF) / 255f;

        VertexConsumer buffer = vcp.getBuffer(RenderLayer.getLines());
        Matrix4f model = matrices.peek().getPositionMatrix();
        buffer.vertex(model, 0, 0, 0).color(r, g, b, a).normal(0, 1, 0);
        buffer.vertex(model, 0, 256, 0).color(r, g, b, a).normal(0, 1, 0);

        matrices.pop();
    }
}
